# This file contains modules common to various models
import math

import torch
import torch.nn as nn
from utils.general import non_max_suppression
import argparse # 首先导入命令行解析模块
import logging
import math


from utils.autoanchor import check_anchor_order
from models.common import *
from utils.general import make_divisible, check_file, set_logging
from utils.torch_utils import *

from thop import profile

logger = logging.getLogger(__name__)


import os
os.environ['CUDA_VISIBLE_DEVICES']='1'
device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')


class Conv(nn.Module):  # 自定义卷积块：卷积_BN_激活。类比yolov4里的CBL结构
    def __init__(self, c1, c2, k=1, s=1, p=0, g=1, act=True):  # ch_in, ch_out, kernel, stride, padding, groups=1
        super().__init__()
        self.conv = nn.Conv2d(c1, c2, k, s, p, groups=g, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = nn.SiLU() if act is True else (act if isinstance(act, nn.Module) else nn.Identity())

    def forward(self, x):   # 前向计算
        x1 = self.conv(x)
        x2 = self.bn(x1)
        return self.act(x2)

    def fuseforward(self, x):  # 前向融合计算
        return self.act(self.conv(x))


## 把宽度w和高度h的信息整合到通道空间中
## Focus模块，输入通道扩充了4倍，作用是可以使信息不丢失的情况下提高计算力
class Focus(nn.Module):
    # Focus wh information into c-space
    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, act=True):  # ch_in, ch_out, kernel, stride, padding, groups
        super(Focus, self).__init__()
        self.conv = Conv(c1 * 4, c2, k, s, p, g, act)
        # self.contract = Contract(gain=2)

    def forward(self, x):  # x(b,c,w,h) -> y(b,4c,w/2,h/2)
        return self.conv(torch.cat([x[..., ::2, ::2], x[..., 1::2, ::2], x[..., ::2, 1::2], x[..., 1::2, 1::2]], 1))
        # return self.conv(self.contract(x))


class Bottleneck(nn.Module):
    # Standard bottleneck
    def __init__(self, c1, c2, shortcut=True, g=1, e=0.5):  # ch_in, ch_out, shortcut, groups, expansion
        super(Bottleneck, self).__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c_, c2, 3, 1, 1, g=g)
        self.add = shortcut and c1 == c2

    def forward(self, x):
        return x + self.cv2(self.cv1(x)) if self.add else self.cv2(self.cv1(x))

class BottleneckCSP(nn.Module):
    def __init__(self, c1, c2, e=1, shortcut=True, num=3):
        super().__init__()
        # c1 = int(c1*e)
        self.cv1 = Conv(c1, c2, k=1, s=1, p=0, act=True)
        self.cv2 = nn.Conv2d(c1, c2, 1, 1, bias=False)
        self.cv3 = nn.Conv2d(c2, c2, 1, 1, bias=False)
        if e == 1:
            self.cv4 = Conv(c1, c1, k=1, s=1, p=0)
            self.bn = nn.BatchNorm2d(c1)
        else:
            self.cv4 = Conv(int(c1 * 0.5), int(c1 * 0.5), k=1, s=1, p=0)
            self.bn = nn.BatchNorm2d(int(c1 * 0.5))

        self.act = nn.LeakyReLU(0.1, inplace=True)
        self.m = nn.Sequential(*[Bottleneck(c2, c2, shortcut, g=1, e=1.0) for _ in range(num)])

    def forward(self, x):
        x1 = self.cv1(x)
        m1 = self.m(x1)
        x2 = self.cv3(m1)
        x3 = self.cv2(x)
        cat1 = torch.cat((x2, x3), dim=1)
        bn1 = self.bn(cat1)
        act1 = self.act(bn1)
        return self.cv4(act1)


class C3(nn.Module):
    # CSP Bottleneck with 3 convolutions
    def __init__(self, c1, c2, e=1, shortcut=True, num=3):  # ch_in, ch_out, number, shortcut, groups, expansion
        super().__init__()
        # c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c2, 1, 1)
        self.cv2 = Conv(c1, c2, 1, 1)
        if e == 1:
            self.cv3 = Conv(c1, c1, 1)
        else:
            self.cv3 = Conv(int(c1 * 0.5), int(c1 * 0.5), 1)

        self.m = nn.Sequential(*[Bottleneck(c2, c2, shortcut, g=1, e=1.0) for _ in range(num)])
        # self.m = nn.Sequential(*[CrossConv(c_, c_, 3, 1, g, 1.0, shortcut) for _ in range(n)])

    def forward(self, x):
        # return self.cv3(torch.cat((self.m(self.cv1(x)), self.cv2(x)), dim=1))
        m1 = self.m(self.cv1(x))
        x2 = self.cv2(x)
        cat1 = torch.cat((m1, x2), dim=1)
        return self.cv3(cat1)

class C32(nn.Module):
    # CSP Bottleneck with 3 convolutions
    def __init__(self, c1, c2, e=1, shortcut=True, num=3):  # ch_in, ch_out, number, shortcut, groups, expansion
        super().__init__()
        # c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c2, 1, 1)
        self.cv2 = Conv(c1, c2, 1, 1)
        c12 = int(2*c1)
        if e == 1:
            self.cv3 = Conv(c1, c12, 1)
        else:
            self.cv3 = Conv(int(c1 * 0.5), int(c1 * 0.5), 1)

        self.m = nn.Sequential(*[Bottleneck(c2, c2, shortcut, g=1, e=1.0) for _ in range(num)])
        # self.m = nn.Sequential(*[CrossConv(c_, c_, 3, 1, g, 1.0, shortcut) for _ in range(n)])

    def forward(self, x):
        # return self.cv3(torch.cat((self.m(self.cv1(x)), self.cv2(x)), dim=1))
        m1 = self.m(self.cv1(x))
        x2 = self.cv2(x)
        cat1 = torch.cat((m1, x2), dim=1)
        return self.cv3(cat1)

#### neck
class SPP(nn.Module):
    # Spatial pyramid pooling layer used in YOLOv3-SPP
    def __init__(self, c1, c2, k=(5, 9, 13)):
        super().__init__()
        self.cv1 = Conv(c1, c2, 1, 1)
        self.cv2 = Conv(c2 * (len(k) + 1), c1, 1, 1)
        # self.maxpool1 = nn.MaxPool2d(kernel_size=5, stride=1, padding=5 // 2)
        # self.maxpool2 = nn.MaxPool2d(kernel_size=9, stride=1, padding=9 // 2)
        # self.maxpool3 = nn.MaxPool2d(kernel_size=13, stride=1, padding=13 // 2)
        self.m = nn.ModuleList([nn.MaxPool2d(kernel_size=x, stride=1, padding=x // 2) for x in k])

    def forward(self, x):
        x1 = self.cv1(x)
        x2 = torch.cat([x1] + [m(x1) for m in self.m], 1)
        return self.cv2(x2)

class SPPF(nn.Module):
    # Spatial Pyramid Pooling - Fast (SPPF) layer for YOLOv5 by Glenn Jocher
    def __init__(self, c1, c2, k=5):  # equivalent to SPP(k=(5, 9, 13))
        super().__init__()
        c_ = c1 // 2  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c_ * 4, c2, 1, 1)
        self.m = nn.MaxPool2d(kernel_size=k, stride=1, padding=k // 2)

    def forward(self, x):
        x = self.cv1(x)
        with warnings.catch_warnings():
            warnings.simplefilter('ignore')  # suppress torch 1.9.0 max_pool2d() warning
            y1 = self.m(x)
            y2 = self.m(y1)
            return self.cv2(torch.cat([x, y1, y2, self.m(y2)], 1))



class Concat(nn.Module):
    def __init__(self, dimension=1):
        super().__init__()
        self.d = dimension

    def forward(self, x1, x2):
        return torch.cat((x1, x2), dim=1)


class NMS(nn.Module):
    # Non-Maximum Suppression (NMS) module
    conf = 0.25  # confidence threshold
    iou = 0.45  # IoU threshold
    classes = None  # (optional list) filter by class

    def __init__(self):
        super(NMS, self).__init__()

    def forward(self, x):
        return non_max_suppression(x[0], conf_thres=self.conf, iou_thres=self.iou, classes=self.classes)


# ---------------------------------------------------- #
# CBAM注意力机制
# ---------------------------------------------------- #
# （1）通道注意力机制
class channel_attention(nn.Module):
    # 初始化, in_channel代表输入特征图的通道数, ratio代表第一个全连接的通道下降倍数
    def __init__(self, in_channel, ratio=4):
        # 继承父类初始化方法
        super(channel_attention, self).__init__()

        # 全局最大池化 [b,c,h,w]==>[b,c,1,1]
        self.max_pool = nn.AdaptiveMaxPool2d(output_size=1)
        # 全局平均池化 [b,c,h,w]==>[b,c,1,1]
        self.avg_pool = nn.AdaptiveAvgPool2d(output_size=1)

        # 第一个全连接层, 通道数下降4倍
        self.fc1 = nn.Linear(in_features=in_channel, out_features=in_channel // ratio, bias=False)
        # 第二个全连接层, 恢复通道数
        self.fc2 = nn.Linear(in_features=in_channel // ratio, out_features=in_channel, bias=False)

        # relu激活函数
        self.relu = nn.ReLU()
        # sigmoid激活函数
        self.sigmoid = nn.Sigmoid()

    # 前向传播
    def forward(self, inputs):
        # 获取输入特征图的shape
        b, c, h, w = inputs.shape

        # 输入图像做全局最大池化 [b,c,h,w]==>[b,c,1,1]
        max_pool = self.max_pool(inputs)
        # 输入图像的全局平均池化 [b,c,h,w]==>[b,c,1,1]
        avg_pool = self.avg_pool(inputs)

        # 调整池化结果的维度 [b,c,1,1]==>[b,c]
        max_pool = max_pool.view([b, c])
        avg_pool = avg_pool.view([b, c])

        # 第一个全连接层下降通道数 [b,c]==>[b,c//4]
        x_maxpool = self.fc1(max_pool)
        x_avgpool = self.fc1(avg_pool)

        # 激活函数
        x_maxpool = self.relu(x_maxpool)
        x_avgpool = self.relu(x_avgpool)

        # 第二个全连接层恢复通道数 [b,c//4]==>[b,c]
        x_maxpool = self.fc2(x_maxpool)
        x_avgpool = self.fc2(x_avgpool)

        # 将这两种池化结果相加 [b,c]==>[b,c]
        x = x_maxpool + x_avgpool
        # sigmoid函数权值归一化
        x = self.sigmoid(x)
        # 调整维度 [b,c]==>[b,c,1,1]
        x = x.view([b, c, 1, 1])
        # 输入特征图和通道权重相乘 [b,c,h,w]
        outputs = inputs * x

        return outputs


# ---------------------------------------------------- #
# （2）空间注意力机制
class spatial_attention(nn.Module):
    # 初始化，卷积核大小为7*7
    def __init__(self, kernel_size=7):
        # 继承父类初始化方法
        super(spatial_attention, self).__init__()

        # 为了保持卷积前后的特征图shape相同，卷积时需要padding
        padding = kernel_size // 2
        # 7*7卷积融合通道信息 [b,2,h,w]==>[b,1,h,w]
        self.conv = nn.Conv2d(in_channels=2, out_channels=1, kernel_size=kernel_size,
                              padding=padding, bias=False)
        # sigmoid函数
        self.sigmoid = nn.Sigmoid()

    # 前向传播
    def forward(self, inputs):
        # 在通道维度上最大池化 [b,1,h,w]  keepdim保留原有深度
        # 返回值是在某维度的最大值和对应的索引
        x_maxpool, _ = torch.max(inputs, dim=1, keepdim=True)

        # 在通道维度上平均池化 [b,1,h,w]
        x_avgpool = torch.mean(inputs, dim=1, keepdim=True)
        # 池化后的结果在通道维度上堆叠 [b,2,h,w]
        x = torch.cat([x_maxpool, x_avgpool], dim=1)

        # 卷积融合通道信息 [b,2,h,w]==>[b,1,h,w]
        x = self.conv(x)
        # 空间权重归一化
        x = self.sigmoid(x)
        # 输入特征图和空间权重相乘
        outputs = inputs * x

        return outputs


# ---------------------------------------------------- #
# （3）CBAM注意力机制
class cbam(nn.Module):
    # 初始化，in_channel和ratio=4代表通道注意力机制的输入通道数和第一个全连接下降的通道数
    # kernel_size代表空间注意力机制的卷积核大小
    def __init__(self, in_channel, ratio=4, kernel_size=7):
        # 继承父类初始化方法
        super(cbam, self).__init__()

        # # 实例化通道注意力机制
        self.channel_attention = channel_attention(in_channel=in_channel, ratio=ratio)
        # 实例化空间注意力机制
        self.spatial_attention = spatial_attention(kernel_size=kernel_size)

    # 前向传播
    def forward(self, inputs):
        # 先将输入图像经过通道注意力机制
        x = self.channel_attention(inputs)
        # 然后经过空间注意力机制
        x = self.spatial_attention(x)

        return x


class Detect(nn.Module):
    stride = None  # strides computed during build
    onnx_dynamic = False  # ONNX export parameter

    # def __init__(self, nc=5, anchors=(), ch=(), inplace=True):  # detection layer
    #     super().__init__()

    def __init__(self, inference=False, nc=5):  # detection layer
        super().__init__()
        self.inference = inference

        anchors = [[5, 6, 10, 11, 18, 19, 31, 28],  # P1/2/
                   [45, 44, 71, 64, 100, 98, 142, 134]]  # P3/8


        self.nc = nc  # number of classes
        self.no = nc + 5  # number of outputs per anchor
        self.nl = len(anchors)  # number of detection layers
        self.na = len(anchors[0]) // 2  # number of anchors
        self.grid = [torch.zeros(1)] * self.nl  # init grid
        self.anchor_grid = [torch.zeros(1)] * self.nl  # init anchor grid
        self.register_buffer('anchors', torch.tensor(anchors).float().view(self.nl, -1, 2))  # shape(nl,na,2)
        # self.m = nn.ModuleList(nn.Conv2d(x, self.no * self.na, 1) for x in ch)  # output conv
        # self.m = nn.ModuleList(nn.Conv2d(x, self.no * self.na, 1) for x in [128, 256, 512])  # output conv
        self.m = nn.ModuleList(nn.Conv2d(x, self.no * self.na, 1) for x in [64, 256])  # output conv


    def forward(self, x):
        z = []  # inference output
        for i in range(self.nl):
            x[i] = self.m[i](x[i])  # conv
            bs, _, ny, nx = x[i].shape  # x(bs,255,20,20) to x(bs,3,20,20,85)
            x[i] = x[i].view(bs, self.na, self.no, ny, nx).permute(0, 1, 3, 4, 2).contiguous()

            # if not self.training:  # inference
            if self.inference:
                if self.onnx_dynamic or self.grid[i].shape[2:4] != x[i].shape[2:4]:
                    self.grid[i], self.anchor_grid[i] = self._make_grid(nx, ny, i)

                y = x[i].sigmoid()

                y[..., 0:2] = (y[..., 0:2] * 2 - 0.5 + self.grid[i]) * self.stride[i]  # xy
                y[..., 2:4] = (y[..., 2:4] * 2) ** 2 * self.anchor_grid[i]  # wh
                # else:  # for YOLOv5 on AWS Inferentia https://github.com/ultralytics/yolov5/pull/2953
                #     xy = (y[..., 0:2] * 2 - 0.5 + self.grid[i]) * self.stride[i]  # xy
                #     wh = (y[..., 2:4] * 2) ** 2 * self.anchor_grid[i]  # wh
                #     y = torch.cat((xy, wh, y[..., 4:]), -1)

                z.append(y.view(bs, -1, self.no))

        # return x if self.training else (torch.cat(z, 1), x)

        if self.inference:
            return torch.cat(z, 1), x

        else:
            return x

    def _make_grid(self, nx=20, ny=20, i=0):
        d = self.anchors[i].device
        if check_version(torch.__version__, '1.10.0'):  # torch>=1.10.0 meshgrid workaround for torch>=0.7 compatibility
            yv, xv = torch.meshgrid([torch.arange(ny, device=d), torch.arange(nx, device=d)], indexing='ij')
        else:
            yv, xv = torch.meshgrid([torch.arange(ny, device=d), torch.arange(nx, device=d)])
        grid = torch.stack((xv, yv), 2).expand((1, self.na, ny, nx, 2)).float()
        anchor_grid = (self.anchors[i].clone() * self.stride[i]) \
            .view((1, self.na, 1, 1, 2)).expand((1, self.na, ny, nx, 2)).float()
        return grid, anchor_grid



class Yolov5(nn.Module):
    # def __init__(self, training=True):  # model, input channels, number of classes
    def __init__(self, inference=False):  # model, input channels, number of classes
        super().__init__()
        self.inference = inference

        # backbone
        lay0 = Conv(3, 32, k=3, s=1, p=1)
        lay1 = Conv(32, 32, k=3, s=2, p=1)  # /2
        # lay2 = Conv(32, 64, k=3, s=1, p=1)
        lay2 = C32(32, 16, num=1)
        lay3 = Conv(64, 64, k=3, s=2, p=1)  # /4
        lay4 = C32(64, 32, num=1)
        lay5 = Conv(128, 128, k=3, s=2, p=1)  # /8
        lay6 = C32(128, 64, num=2)
        lay7 = Conv(256, 256, k=3, s=2, p=1)  # /16
        lay8 = C32(256, 128, num=2)
        lay9 = Conv(512, 512, k=3, s=2, p=1)  # /32
        lay10 = C3(512, 256, num=1)
        lay11 = SPPF(512, 512)

        lay12 = Conv(512, 256, k=1, s=1, p=0)
        lay13 = nn.Upsample(scale_factor=2, mode='nearest')  # /16
        lay14 = Concat()
        lay15 = C3(512, 128, e=0.5, shortcut=False, num=1)
        lay16 = Conv(256, 128, k=1, s=1, p=0)
        lay17 = nn.Upsample(scale_factor=2, mode='nearest')  # /8
        lay18 = Concat()
        lay19 = C3(256, 64, e=0.5, shortcut=False, num=1)
        lay20 = Conv(128, 64, k=1, s=1, p=0)
        lay21 = nn.Upsample(scale_factor=2, mode='nearest')  # /4
        lay22 = Concat()
        lay23 = C3(128, 32, e=0.5, shortcut=False, num=1)  # /det

        lay24 = Conv(64, 32, k=1, s=1, p=0)
        lay25 = nn.Upsample(scale_factor=2, mode='nearest')  # /2
        lay26 = Concat()
        lay27 = C3(64, 16, e=0.5, shortcut=False, num=1)

        lay28 = Conv(32, 16, k=1, s=1, p=0)
        lay29 = nn.Upsample(scale_factor=2, mode='nearest')  # /1
        lay30 = Concat()
        lay31 = Conv(32, 16, k=3, s=1, p=1)

        lay32 = nn.Conv2d(16, 1, kernel_size=3, padding=1)
        lay33 = nn.Conv2d(32, 1, kernel_size=3, padding=1)

        lay34 = Conv(512, 256, k=1, s=1, p=0)
        lay35 = Conv(256, 128, k=1, s=1, p=0)
        lay36 = Conv(128, 64, k=1, s=1, p=0)
        lay37 = Conv(64, 32, k=1, s=1, p=0)
        lay38 = Conv(32, 16, k=1, s=1, p=0)

        lay39 = Conv(64, 64, k=3, s=2, p=1)  # /8
        lay40 = Concat()
        lay41 = C3(128, 64, e=1, shortcut=False, num=1)
        lay42 = Conv(128, 128, k=3, s=2, p=1)  # /16
        lay43 = Concat()
        lay44 = C3(256, 128, e=1, shortcut=False, num=1)  # /det

        # detect head
        lay45 = Detect(inference)

        self.model = nn.Sequential(lay0, lay1, lay2, lay3, lay4, lay5, lay6, lay7, lay8, lay9, lay10, lay11, lay12,
                                   lay13, lay14, lay15, lay16, lay17, lay18, lay19, lay20, lay21, lay22, lay23, lay24,
                                   lay25, lay26, lay27, lay28, lay29, lay30, lay31, lay32, lay33, lay34, lay35, lay36,
                                   lay37, lay38, lay39, lay40, lay41, lay42, lay43, lay44, lay45)

        self.atten1 = cbam(in_channel = 32)
        self.atten2 = cbam(in_channel=64)
        self.gamma1 = nn.Parameter(torch.ones(1))

        # Build strides, anchors
        m = self.model[-1]  # Detect()
        #  若 m和Detect类型相等，则返回true
        if isinstance(m, Detect):
            # s = 128  # 2x min stride
            # m.stride = torch.tensor([8., 16., 32.])
            m.stride = torch.tensor([4., 16.])
            # m.stride = torch.tensor([s / x.shape[-2] for x in self.forward(torch.zeros(1, 3, s, s))])  # forward
            # m.anchors 为不同检测层对应的先验框尺度大小（原尺度对应除以下采样倍数 4, 8，16，32）
            m.anchors /= m.stride.view(-1, 1, 1)
            # m.anchors /= m.stride.view(-1, 1)
            check_anchor_order(m)
            self.stride = m.stride  # self.stride = <class 'torch.Tensor'>
            self._initialize_biases()  # only run once
            # Init weights, biases
        initialize_weights(self)


    def _initialize_biases(self, cf=None):  # initialize biases into Detect(), cf is class frequency
        # https://arxiv.org/abs/1708.02002 section 3.3
        # cf = torch.bincount(torch.tensor(np.concatenate(dataset.labels, 0)[:, 0]).long(), minlength=nc) + 1.
        m = self.model[-1]  # Detect() module
        # m.stride = tensor([ 8., 16., 32.])
        # mi为检测端的每层卷积
        for mi, s in zip(m.m, m.stride):  # from
            b = mi.bias.view(m.na, -1)  # conv.bias(255) to (3,85)
            b.data[:, 4] += math.log(8 / (416 / s) ** 2)  # obj (8 objects per 640 image)
            b.data[:, 5:] += math.log(0.6 / (m.nc - 0.99)) if cf is None else torch.log(cf / cf.sum())  # cls
            # b[:, 4] += math.log(8 / (640 / s) ** 2)  # obj (8 objects per 640 image)
            # b[:, 5:] += math.log(0.6 / (m.nc - 0.99)) if cf is None else torch.log(cf / cf.sum())  # cls
            mi.bias = torch.nn.Parameter(b.view(-1), requires_grad=True)


    def fuse(self):  # fuse model Conv2d() + BatchNorm2d() layers
        print('Fusing layers... ')
        for m in self.model.modules():
            if type(m) is Conv and hasattr(m, 'bn'):
                m.conv = fuse_conv_and_bn(m.conv, m.bn)  # update conv
                delattr(m, 'bn')  # remove batchnorm
                m.forward = m.fuseforward  # update forward
        # self.info()
        return self


    def nms(self, mode=True):  # add or remove NMS module
        present = type(self.model[-1]) is NMS  # last layer is NMS
        if mode and not present:
            print('Adding NMS... ')
            m = NMS()  # module
            m.f = -1  # from
            m.i = self.model[-1].i + 1  # index
            self.model.add_module(name='%s' % m.i, module=m)  # add
            self.eval()
        elif not mode and present:
            print('Removing NMS... ')
            self.model = self.model[:-1]  # remove
        return self


    def forward(self, input):

        d0 = self.model[0](input)
        d1 = self.model[1](d0) # /2
        d1 = self.atten1(d1)
        d2 = self.model[2](d1) # 128ch
        d3 = self.model[3](d2) # /4
        d3 = self.atten2(d3)
        d4 = self.model[4](d3)
        d5 = self.model[5](d4) # /8
        d6 = self.model[6](d5) # 512ch
        d7 = self.model[7](d6) # /16
        d8 = self.model[8](d7) # 1024ch
        d9 = self.model[9](d8) # /32
        d10 = self.model[10](d9)
        sppf = self.model[11](d10)

        cn1 = self.model[12](sppf)
        up1 = self.model[13](cn1) # /16
        d82 = self.model[34](d8)
        c14 = self.model[14](d82, up1)
        c15 = self.model[15](c14)
        c16 = self.model[16](c15)
        c17 = self.model[17](c16)# /8
        d62 = self.model[35](d6)
        c18 = self.model[18](d62, c17)
        c19 = self.model[19](c18)
        c20 = self.model[20](c19)
        c21 = self.model[21](c20)# /4
        d42 = self.model[36](d4)
        c22 = self.model[22](d42, c21)
        c23 = self.model[23](c22) # det
        c24 = self.model[24](c23)
        c25 = self.model[25](c24) # /2
        d22 = self.model[37](d2)
        c26 = self.model[26](d22, c25)
        c27 = self.model[27](c26)
        c28 = self.model[28](c27)
        c29 = self.model[29](c28)  # /1
        d02 = self.model[38](d0)
        c30 = self.model[30](d02, c29)
        c31 = self.model[31](c30)
        c32 = self.model[32](c31)
        c33 = self.model[33](c27)
        out1 = torch.sigmoid(c32)
        out2 = torch.sigmoid(c33)

        d0 = self.model[0](input)
        f1 = self.gamma1 * out1 * d0
        d02 = f1 + d0
        d1 = self.model[1](d02)  # /2
        d1 = self.atten1(d1)
        f2 = self.gamma1 * out2 * d1
        d12 = f2 + d1
        d2 = self.model[2](d12) # 128ch
        d3 = self.model[3](d2) # /4
        d3 = self.atten2(d3)
        d4 = self.model[4](d3)
        d5 = self.model[5](d4) # /8
        d6 = self.model[6](d5) # 512ch
        d7 = self.model[7](d6) # /16
        d8 = self.model[8](d7) # 1024ch
        d9 = self.model[9](d8) # /32
        d10 = self.model[10](d9)
        sppf = self.model[11](d10)

        cn1 = self.model[12](sppf)
        up1 = self.model[13](cn1) # /16
        d82 = self.model[34](d8)
        c14 = self.model[14](d82, up1)
        c15 = self.model[15](c14)
        c16 = self.model[16](c15)
        c17 = self.model[17](c16)# /8
        d62 = self.model[35](d6)
        c18 = self.model[18](d62, c17)
        c19 = self.model[19](c18)
        c20 = self.model[20](c19)
        c21 = self.model[21](c20)# /4
        d42 = self.model[36](d4)
        c22 = self.model[22](d42, c21)
        c23 = self.model[23](c22) # det

        c39 = self.model[39](c23) # /8
        c40 = self.model[40](c20, c39)
        c41 = self.model[41](c40)
        c42 = self.model[42](c41) # /16
        c43 = self.model[43](c16, c42)
        c44 = self.model[44](c43)  # de

        if self.inference:
            inf_out, train_out = self.model[45]([c23, c44])

            return inf_out, train_out

        else:
            pred = self.model[45]([c23, c44])
            return pred, out1, out2
