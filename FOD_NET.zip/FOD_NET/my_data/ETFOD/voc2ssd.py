import os
import random 


xmlfilepath = r".../train_xml" # label
saveBasePath = r".../ImageSets"
if not os.path.exists(saveBasePath):
    os.makedirs(saveBasePath )


trainval_percent=1
train_percent=1

temp_xml = os.listdir(xmlfilepath)
# temp_xml = os.listdir(xmlfilepath)  # 返回指定路径下的文件和文件夹列表。
print(temp_xml)
total_xml = []
for xml in temp_xml:
    if xml.endswith(".xml"):
        total_xml.append(xml)
        # print(total_xml)

num=len(total_xml)  
list=range(num)  
tv=int(num*trainval_percent)  
tr=int(tv*train_percent)  
trainval= random.sample(list,tv)  
train=random.sample(trainval,tr)  
 
print("train and val size",tv)
print("traub suze",tr)
ftrainval = open(os.path.join(saveBasePath,'trainval.txt'), 'w')  
ftest = open(os.path.join(saveBasePath,'test.txt'), 'w')  
ftrain = open(os.path.join(saveBasePath,'train.txt'), 'w')  
fval = open(os.path.join(saveBasePath,'val.txt'), 'w')  
 
for i  in list:  
    name=total_xml[i][:-4]+'\n'  
    if i in trainval:  
        ftrainval.write(name)  
        if i in train:  
            ftrain.write(name)  
        else:  
            # ftest.write(name)
            fval.write(name)
    else:  
        # fval.write(name)
        ftest.write(name)
  
ftrainval.close()  
ftrain.close()  
fval.close()  
ftest.close()
print('---have done---')
